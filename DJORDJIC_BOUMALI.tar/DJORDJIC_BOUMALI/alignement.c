									#include <stdio.h>
									#include <stdlib.h>
									#include <unistd.h>
									#include <string.h>
									#include "sequence.h"
									#include "distance.h"
									#include "alignement.h"
									#include "famille.h"
									
									
									void creer_familles(char **argv , FAMILLE *f , SEQUENCE *D)
									{
										//clear_all(argv);
										initialiser_tab_seq(D,argv);
										afficher_tab(D);
										LISTE *l = creer_liste_initiale(D,argv);
										
										
										int T[10] , numero , taille ;
										float d ;
										int i = 0 ;
										while(!est_vide(l))
										{
											
											d = recherche_distance_min(l);
											numero  = get_num_freq_max(d,l);
											T[0] = numero  ;
											taille =get_num_autre(T,d,numero,l);
											f[i] = creer_famille_initiale(taille);
											remplir_famille(f[i],T,D);
											ecrire_fich_fam(f[i],T,argv[23+i]);
									
											for(int j = 0 ; j < taille ; j++)
											{
												supp_numero_seq(l,T[j]);
											}
											ecrire_fichier_liste_fin(l,argv[22]);
											i++;
											
										}
									}

									
									float distance_rec(CHAINES S , int i , int j ,float distance , float **T)
									{
										float d1,d2,d3,m;
										int nouvelletailleA , nouvelletailleB ;
										nouvelletailleA = strlen(S.a);
										nouvelletailleB = strlen(S.b);
										if(i == 0 && j > 0)
										{		
											/*for(int rep = 0 ; rep < j ; rep++)
											{
												for(int k = strlen(nouvelletailleA)-1 ; k > 0 ; k--)
												{
													S.anew[k] = S.anew[k-1] ;
												}
												S.anew[0] = '-' ;
												//printf("nouvelletailleA : %d\n",nouvelletailleA);
												//nouvelletailleA++;
											}*/
											
											return ( distance + 1.5 * j );
										}
												
										else if ( j == 0 && i > 0)
										{
											return (distance + 1.5 *i );
										}
											
										else if ( i == 0 && j == 0)
										{
											return (distance + compare_carac(S.a[i],S.b[j])) ;	
										}
											
										else if ( T[i][j] != -(1) )
										{
											return T[i][j] ;
										}
										
										else
										{
											d1 = distance_rec(S,i-1,j-1,distance,T) + compare_carac(S.a[i],S.b[j]) ;
											d2 = distance_rec(S,i-1,j,distance,T) + compare_carac(S.a[i],'-') ;
											d3 = distance_rec(S,i,j-1,distance,T) + compare_carac('-',S.b[j]) ;
											
											//m = min(min(d1,d2),d3);	
											if( d1 <= d2 && d1 <= d3 )
											{
												printf("i : %d , j : %d (d1) \n",i,j);
												m = d1 ;
											}
											
											else if( strlen(S.a) > strlen(S.b) )
											{
												if ( d2 <= d3 )
												{
													printf("i : %d , j : %d (d2) \n",i,j);
													S.bnew[nouvelletailleB+1] = '\0' ;
													S.bnew[nouvelletailleB] = S.bnew[nouvelletailleB-1];
													for(int k = nouvelletailleB-1 ; k > j+1; k--)
													{
														S.bnew[k] = S.bnew[k-1] ;
													}
													S.bnew[j+1] = '-' ;
													nouvelletailleB++;
													/*for(int l = 0 ; l < i ; l++)
													{
														S.bnew[l] = S.b[l] ;
													}*/
													m = d2 ;
												}
												
												else 
												{
													printf("i : %d , j : %d (d3) \n",i,j);
													S.anew[nouvelletailleA+1] = '\0' ;
													S.anew[nouvelletailleA] = S.anew[nouvelletailleA-1] ;
													for(int k = nouvelletailleA-1 ; k > i+1 ; k--)
													{
														S.anew[k] = S.anew[k-1] ;
													}
													S.anew[i+1] = '-' ;
													nouvelletailleA++;
													/*for(int l = 0 ; l < j ; l++)
													{
														S.bnew[l] = S.b[l] ;
													}*/
													m = d3 ;
												}
											}
											else 
											{
												if ( d3 <= d2 )
												{
													printf("i : %d , j : %d (d3) \n",i,j);
													S.anew[nouvelletailleA+1] = '\0' ;
													S.anew[nouvelletailleA] = S.anew[nouvelletailleA-1] ;
													for(int k = nouvelletailleA-1 ; k > i+1 ; k--)
													{
														S.anew[k] = S.anew[k-1] ;
													}
													S.anew[i+1] = '-' ;
													nouvelletailleA++;
													/*for(int l = 0 ; l < j ; l++)
													{
														S.bnew[l] = S.b[l] ;
													}*/
													m = d3 ;
												}
												
												else 
												{
													printf("i : %d , j : %d (d2) \n",i,j);
													S.bnew[nouvelletailleB+1] = '\0' ;
													S.bnew[nouvelletailleB] = S.bnew[nouvelletailleB-1];
													for(int k = nouvelletailleB-1 ; k > j+1; k--)
													{
														S.bnew[k] = S.bnew[k-1] ;
													}
													S.bnew[j+1] = '-' ;
													nouvelletailleB++;
													/*for(int l = 0 ; l < i ; l++)
													{
														S.bnew[l] = S.b[l] ;
													}*/
													m = d2 ;
												}
											}
																					
											T[i][j] = m ;
										}
											
										return T[i][j] ;		
									}
											
										
