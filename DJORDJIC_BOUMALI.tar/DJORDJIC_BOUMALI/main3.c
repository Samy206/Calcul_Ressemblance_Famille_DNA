									#include <stdio.h>
									#include <stdlib.h>
									#include <unistd.h>
									#include <string.h>
									#include "sequence.h"
									#include "distance.h"
									#include "alignement.h"
									#include "famille.h"
									
									int main(int argc , char ** argv )
									{
										srand(getpid());
										//int alea1 , alea2 ;
										FAMILLE f[6];
										SEQUENCE D[21];
										creer_familles(argv,f,D);
										CHAINES S ;
										S.a = malloc(20);
										
										S.b = malloc(20);
										
										S.anew = malloc(40);
										S.bnew = malloc(40);
										
										float **T = malloc(19*sizeof(float));
										for(int i = 0 ; i < 19 ; i++ )
										{
											T[i] = malloc(19*sizeof(float));
										}
										float d;
										for(int i = 0 ; i < 1 ; i++)
										{
											remplir_tab(T,19,19);
											//alea1 = (rand()%19)+1 ;
											//alea2 = (rand()%19) +1;
											strcpy(S.a,"AAAT");
											strcpy(S.b,"AAA");
											strcpy(S.anew,"AAAT");
											strcpy(S.bnew,"AAA");
											//printf("alea1 : %d , alea2 : %d \n",alea1,alea2);
											d = distance_rec(S,3,2,0.0,T);
											printf("anew : %s , bnew : %s , distance : %f \n",S.anew,S.bnew,d);
										}
										exit(0);
									}
